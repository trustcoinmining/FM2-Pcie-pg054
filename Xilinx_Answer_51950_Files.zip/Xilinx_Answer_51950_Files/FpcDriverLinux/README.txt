Xilinx Fast PCIe Configuration (FPC) Example Driver and Application

Customizing:
The driver and application both utilize settings found in the common/ area. To modify design constants, please edit files in that location.


**************************************
* Linux Kernel Module Driver         *
* (see linux_driver directory)       *
**************************************

To Clean:
make clean

To Build:
make

To Use:
sudo insmod xilinx_pci_fpc_main.ko


**************************************
* FPC Test Application               *
* (see linux_test_app directory)     *
**************************************

To Clean:
make clean

To Build:
make

To Run Application:
./test_fpc [file=<file_to_send>]
If no file is specified, the default file name fpc_demo.bin will be used.
