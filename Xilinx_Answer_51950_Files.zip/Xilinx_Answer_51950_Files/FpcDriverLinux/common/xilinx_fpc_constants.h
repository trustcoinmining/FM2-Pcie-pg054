#define XILINX_VENDOR_ID 0x10EE
#define FPC_DEVICE_ID    0x7024
#define FPC_DESCRIPTION  "Xilinx FPC Example"
#define FPC_BAR_NUM      0
