// Precompiled header
#include "Precomp.h"

// System headers
#include <ntddk.h>
#include <wdf.h>
#include <wdfdevice.h>

// Function prototypes
DRIVER_INITIALIZE               DriverEntry;
EVT_WDF_DRIVER_DEVICE_ADD       FpcEvtDeviceAdd;
EVT_WDF_DEVICE_PREPARE_HARDWARE FpcEvtDevicePrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE FpcEvtDeviceReleaseHardware;
EVT_WDF_DEVICE_D0_ENTRY         FpcEvtDeviceD0Entry;
EVT_WDF_DEVICE_D0_EXIT          FpcEvtDeviceD0Exit;
EVT_WDF_DEVICE_FILE_CREATE      FpcEvtDeviceFileCreate;
EVT_WDF_FILE_CLOSE              FpcEvtFileClose;

#ifdef ALLOC_PRAGMA
#pragma alloc_text (INIT, DriverEntry)
#pragma alloc_text (PAGE, FpcEvtDeviceAdd)
#pragma alloc_text (PAGE, FpcEvtDevicePrepareHardware)
#pragma alloc_text (PAGE, FpcEvtDeviceReleaseHardware)
#pragma alloc_text (PAGE, FpcEvtDeviceD0Exit)
#pragma alloc_text (PAGE, FpcInitializeDeviceExtension)
#endif

// Device driver entry method
NTSTATUS DriverEntry(PDRIVER_OBJECT DriverObject, PUNICODE_STRING RegistryPath)
{
    NTSTATUS status = STATUS_SUCCESS;
    WDF_DRIVER_CONFIG config = {0};
 
    DbgPrint(("FpcDriver : DriverEntry\n"));
    KdPrintEx(( DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, "Fpc: DriverEntry\n" ));
    WDF_DRIVER_CONFIG_INIT(&config, FpcEvtDeviceAdd);
    status = WdfDriverCreate(DriverObject, RegistryPath, WDF_NO_OBJECT_ATTRIBUTES, &config, WDF_NO_HANDLE);
    return status;
}

// Device addition callback
NTSTATUS FpcEvtDeviceAdd(WDFDRIVER Driver, PWDFDEVICE_INIT DeviceInit)
{
    NTSTATUS status = STATUS_SUCCESS;
    WDF_PNPPOWER_EVENT_CALLBACKS pnpPowerCallbacks;
    WDF_OBJECT_ATTRIBUTES attributes;
    WDF_FILEOBJECT_CONFIG fileConfig;
    WDFDEVICE hDevice;
    PDEVICE_EXTENSION devExt = NULL;

    UNREFERENCED_PARAMETER( Driver );

    PAGED_CODE();

    KdPrintEx(( DPFLTR_IHVDRIVER_ID, DPFLTR_INFO_LEVEL, "Fpc: FpcEvtDeviceAdd\n" ));

    // Configure the device to use direct I/O (no buffering)
    WdfDeviceInitSetIoType(DeviceInit, WdfDeviceIoDirect);

    //
    // Zero out the PnpPowerCallbacks structure.
    //
    WDF_PNPPOWER_EVENT_CALLBACKS_INIT(&pnpPowerCallbacks);

    //
    // Set Callbacks for any of the functions we are interested in.
    // If no callback is set, Framework will take the default action
    // by itself.
    //
    pnpPowerCallbacks.EvtDevicePrepareHardware = FpcEvtDevicePrepareHardware;
    pnpPowerCallbacks.EvtDeviceReleaseHardware = FpcEvtDeviceReleaseHardware;

    //
    // These two callbacks set up and tear down hardware state that must be
    // done every time the device moves in and out of the D0-working state.
    //
    pnpPowerCallbacks.EvtDeviceD0Entry = FpcEvtDeviceD0Entry;
    pnpPowerCallbacks.EvtDeviceD0Exit  = FpcEvtDeviceD0Exit;

    //
    // Register the PnP Callbacks
    //
    WdfDeviceInitSetPnpPowerEventCallbacks(DeviceInit, &pnpPowerCallbacks);

    // Initialize an attributes structure for the object, with enough space allocated
    // for our driver's context extension.
    WDF_OBJECT_ATTRIBUTES_INIT_CONTEXT_TYPE(&attributes, DEVICE_EXTENSION);

    // Configure a callback for when the device is opened from user space
    attributes.SynchronizationScope = WdfSynchronizationScopeDevice;

    // TEMPORARY - No file creation callback - this causes the driver to hang
    // when WdfSynchronizationScopeNone is used and a device is opened, or to fail
    // in the call to WdfDeviceCreate() when WdfSynchronizationScopeDevice is used.
//    WDF_FILEOBJECT_CONFIG_INIT(&fileConfig, FpcEvtDeviceFileCreate, WDF_NO_EVENT_CALLBACK, WDF_NO_EVENT_CALLBACK);
//    WdfDeviceInitSetFileObjectConfig(DeviceInit, &fileConfig, &attributes);

    // Create the device instance
    status = WdfDeviceCreate(&DeviceInit, &attributes, &hDevice);
    if (!NT_SUCCESS(status)) {
        //
        // Device Initialization failed.
        //
        DbgPrint("DeviceCreate failed : 0x%08X\n", status);
        return status;
    }

    // Get the allocated device context extension structure and initialize it.
    // FpcGetDeviceContext is an inline function defined by the
    // WDF_DECLARE_CONTEXT_TYPE_WITH_NAME macro in the private header file. 
    // This function will do the type checking and return the device context.
    // Assign navigation back to the enclosing device structure.
    devExt = FpcGetDeviceContext(hDevice);
    devExt->Device = hDevice;

    DbgPrint("AddDevice PDO (0x%p) FDO (0x%p), DevExt (0x%p)\n",
             WdfDeviceWdmGetPhysicalDevice(hDevice),
             WdfDeviceWdmGetDeviceObject(hDevice), devExt);

    //
    // Tell the Framework that this device will need an interface
    //
    // NOTE: See the note in Public.h concerning this GUID value.
    //
    status = WdfDeviceCreateDeviceInterface(hDevice,
                                            (LPGUID) &GUID_FPC_INTERFACE,
                                            NULL);

    if (!NT_SUCCESS(status)) {
        DbgPrint("<-- DeviceCreateDeviceInterface failed : 0x%08X\n", status);
        return status;
    } else {
      DbgPrint("FpcDriver device interface created\n");
    }

    // TODO - Here is where we would set idle and wake settings

    // Initialize the device extension
    status = FpcInitializeDeviceExtension(devExt);
    if (!NT_SUCCESS(status)) {
        DbgPrint("FpcInitializeDeviceExtension() failed\n");
        return(status);
    }

    return(status);
}

// PnP callback to prepare device hardware for use
NTSTATUS FpcEvtDevicePrepareHardware(WDFDEVICE Device,
                                     WDFCMRESLIST ResourcesRaw,
                                     WDFCMRESLIST ResourcesTranslated) {
    NTSTATUS                         status = STATUS_SUCCESS;
    PDEVICE_EXTENSION                devExt;
    PCM_PARTIAL_RESOURCE_DESCRIPTOR  desc;
    PHYSICAL_ADDRESS                 regsBasePA = {0};
    ULONG                            regsLength = 0;
    UINT32                           resIndex;

    UNREFERENCED_PARAMETER(ResourcesRaw);

    PAGED_CODE();

    DbgPrint("FpcEvtDevicePrepareHardware()\n");

    devExt = FpcGetDeviceContext(Device);

    // Loop through the resource descriptors supplied to the driver
    for (resIndex = 0; resIndex < WdfCmResourceListGetCount(ResourcesTranslated); resIndex++) {

      desc = WdfCmResourceListGetDescriptor(ResourcesTranslated, resIndex);
      if(!desc) {
        DbgPrint("WdfResourceCmGetDescriptor failed\n");
        return(STATUS_DEVICE_CONFIGURATION_ERROR);
      }

      // Resolve the type of resource provided
      switch (desc->Type) {

      case CmResourceTypeMemory:
        DbgPrint(" - Memory Resource [%I64X-%I64X]\n",
                 desc->u.Memory.Start.QuadPart,
                 (desc->u.Memory.Start.QuadPart + desc->u.Memory.Length));

        // Only one base address register is expected, and we will map it.
        regsBasePA = desc->u.Memory.Start;
        regsLength = desc->u.Memory.Length;
        break;

      case CmResourceTypePort:
        DbgPrint(" - Port   Resource [%08I64X-%08I64X] %s",
                 desc->u.Port.Start.QuadPart,
                 (desc->u.Port.Start.QuadPart + desc->u.Port.Length - 1));
        break;

      default:
        //
        // Ignore all other descriptors
        DbgPrint("Unrecognized CM resource type %d\n", desc->Type);
        break;
      }
    }

    // Map the register space as uncacheable memory-mapped I/O, unless this is a
    // dummy device node created by devcon.
    devExt->RegsLength = regsLength;
    if(devExt->RegsLength > 0) {
      DbgPrint("Mapped %d bytes of memory at %p\n", devExt->RegsLength, devExt->RegsBase);
      devExt->RegsBase = (PUCHAR) MmMapIoSpace(regsBasePA, regsLength, MmNonCached);
    } else {
      DbgPrint("Dummy device node\n");
      devExt->RegsBase = NULL;
    }

    return(status);
}

NTSTATUS FpcEvtDeviceReleaseHardware(WDFDEVICE Device, WDFCMRESLIST ResourcesTranslated) {
    NTSTATUS          status = STATUS_SUCCESS;
    PDEVICE_EXTENSION devExt;

    DbgPrint("FpcEvtDeviceReleaseHardware()\n");

    devExt = FpcGetDeviceContext(Device);

    // Unmap the register space
    if (devExt->RegsBase) {
        MmUnmapIoSpace(devExt->RegsBase, devExt->RegsLength);
        devExt->RegsBase = NULL;
    }

    return(status);
}

NTSTATUS FpcEvtDeviceD0Entry(WDFDEVICE Device, WDF_POWER_DEVICE_STATE PreviousState) {
    NTSTATUS status = STATUS_SUCCESS;

    DbgPrint("FpcEvtDeviceD0Entry()\n");

    return(status);
}

NTSTATUS FpcEvtDeviceD0Exit(WDFDEVICE Device, WDF_POWER_DEVICE_STATE TargetState) {
    NTSTATUS status = STATUS_SUCCESS;

    DbgPrint("FpcEvtDeviceD0Exit()\n");

    return(status);
}

VOID FpcEvtDeviceFileCreate(WDFDEVICE Device, WDFREQUEST Request, WDFFILEOBJECT FileObject) {
    DbgPrint("FpcEvtDeviceFileCreate()\n");
}

VOID FpcEvtFileClose(WDFFILEOBJECT FileObject) {
    DbgPrint("FpcEvtFileClose()\n");
}

// Initializes the device extension; in essence, this is where the device-specific
// aspects of the driver are configured.
NTSTATUS FpcInitializeDeviceExtension(IN PDEVICE_EXTENSION DevExt) {
    NTSTATUS            status;
    WDF_IO_QUEUE_CONFIG queueConfig;

    PAGED_CODE();

    DbgPrint("FpcInitializeDeviceExtension()\n");

    status = 0;

    // Initialize the reconfiguration state space
    DevExt->reconfig_state = RECONFIG_INIT;
    DevExt->block_count    = 0;
    DevExt->words_left     = 0;

    // Setup a queue to handle only IRP_MJ_WRITE requests in Sequential
    // dispatch mode. This mode ensures there is only one write request
    // outstanding in the driver at any time. Framework will present the next
    // request only if the current request is completed.
    // Since we have configured the queue to dispatch all the specific requests
    // we care about, we don't need a default queue.  A default queue is
    // used to receive requests that are not preconfigured to goto
    // a specific queue.
    //
    WDF_IO_QUEUE_CONFIG_INIT(&queueConfig,
                             WdfIoQueueDispatchSequential);

    queueConfig.EvtIoWrite = FpcEvtIoWrite;

    //
    // Static Driver Verifier (SDV) displays a warning if it doesn't find the 
    // EvtIoStop callback on a power-managed queue. The 'assume' below lets 
    // SDV know not to worry about the EvtIoStop.
    // If not explicitly set, the framework creates power-managed queues when 
    // the device is not a filter driver.  Normally the EvtIoStop is required
    // for power-managed queues, but for this driver it is not need b/c the 
    // driver doesn't hold on to the requests for long time or forward them to
    // other drivers. 
    // If the EvtIoStop callback is not implemented, the framework 
    // waits for all in-flight (driver owned) requests to be done before 
    // moving the device in the Dx/sleep states or before removing the device,
    // which is the correct behavior for this type of driver.
    // If the requests were taking an undetermined amount of time to complete,
    // or the requests were forwarded to a lower driver/another stack, the 
    // queue should have an EvtIoStop/EvtIoResume.
    //
    __analysis_assume(queueConfig.EvtIoStop != 0);
    status = WdfIoQueueCreate(DevExt->Device,
                              &queueConfig,
                              WDF_NO_OBJECT_ATTRIBUTES,
                              &DevExt->WriteQueue );
    __analysis_assume(queueConfig.EvtIoStop == 0);
    
    if(!NT_SUCCESS(status)) {
        DbgPrint("WdfIoQueueCreate failed: %!STATUS!", status);
        return status;
    }

    //
    // Set the Write Queue forwarding for IRP_MJ_WRITE requests.
    //
    status = WdfDeviceConfigureRequestDispatching(DevExt->Device,
                                                  DevExt->WriteQueue,
                                                  WdfRequestTypeWrite);

    if(!NT_SUCCESS(status)) {
        DbgPrint("DeviceConfigureRequestDispatching failed: %!STATUS!", status);
        return status;
    }

    return(status);
}

// Event handler for write IRPs
VOID FpcEvtIoWrite(IN WDFQUEUE   Queue,
                   IN WDFREQUEST Request,
                   IN size_t     Length) {
    PMDL              mdl;
    PULONG32          wordPtr;
    ULONG             length;
    NTSTATUS          status = STATUS_UNSUCCESSFUL;
    PDEVICE_EXTENSION devExt = NULL;

    //
    // Get the device extension from the Queue handle
    //
    devExt = FpcGetDeviceContext(WdfIoQueueGetDevice(Queue));

    // Get access to the bitstream data being written
    status = WdfRequestRetrieveInputWdmMdl(Request, &mdl);
    if (!NT_SUCCESS(status)) {
      DbgPrint("WdfRequestRetrieveInputWdmMdl failed: %!STATUS!", status);
      return;
    }

    wordPtr = (PULONG32) MmGetSystemAddressForMdlSafe(mdl, NormalPagePriority);
    length = MmGetMdlByteCount(mdl);


    _Analysis_assume_(length > 0);

    // If the device has I/O space mapped, write the words out to the PCIe hardware.
    if(devExt->RegsLength > 0) {
      UINT32 wordIndex;
      UINT32 numWords = (length / FPC_BYTES_PER_WORD);

      for(wordIndex = 0; wordIndex < numWords; wordIndex++) {
        // Write to the base address; the entire region is mapped for reconfiguration data.
        WRITE_REGISTER_ULONG((PULONG) devExt->RegsBase, *wordPtr++ );
      }
    }

    // Indicate that the write completed with the requested number of bytes
    status = STATUS_SUCCESS;
    WdfRequestCompleteWithInformation(Request, status, Length);
}