#if !defined(_FPC_PRIVATE_H_)
#define _FPC_PRIVATE_H_

// PCI Device / Vendor Ids.
#define XILINX_VENDOR_ID    0x10EE
#define PCI_FPC_PRODUCT_ID  0x7024

// Enumerated type representing reconfiguration state
typedef enum {
  RECONFIG_INIT     = 0,
  RECONFIG_LOADING,
  RECONFIG_COMPLETE,
  RECONFIG_ERROR
} ReconfigState;

//
// The device extension for the device object
//
typedef struct _DEVICE_EXTENSION {

    // Pointer back to the Windows device
    WDFDEVICE Device;

    // Following fields are specific to the hardware
    // Configuration

    // HW Resources
    PUCHAR RegsBase;         // Registers base address
    ULONG  RegsLength;       // Registers base length

    // Write and device control queue
    WDFQUEUE WriteQueue;

    // Reconfiguration state variables
    ReconfigState         reconfig_state;
    ULONG                 block_count;
    ULONG                 words_left;
//    struct fpc_data_block data_block;
}  DEVICE_EXTENSION, *PDEVICE_EXTENSION;

//
// This will generate the function named FpcGetDeviceContext to be use for
// retreiving the DEVICE_EXTENSION pointer.
//
WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(DEVICE_EXTENSION, FpcGetDeviceContext)

#if !defined(ASSOC_WRITE_REQUEST_WITH_DMA_TRANSACTION)
//
// The context structure used with WdfDmaTransactionCreate
//
typedef struct TRANSACTION_CONTEXT {

    WDFREQUEST     Request;

} TRANSACTION_CONTEXT, * PTRANSACTION_CONTEXT;

WDF_DECLARE_CONTEXT_TYPE_WITH_NAME(TRANSACTION_CONTEXT, FpcGetTransactionContext)

#endif

//
// Function prototypes
//
DRIVER_INITIALIZE DriverEntry;

EVT_WDF_DRIVER_DEVICE_ADD FpcEvtDeviceAdd;

EVT_WDF_OBJECT_CONTEXT_CLEANUP FpcEvtDriverContextCleanup;

EVT_WDF_DEVICE_D0_ENTRY FpcEvtDeviceD0Entry;
EVT_WDF_DEVICE_D0_EXIT FpcEvtDeviceD0Exit;
EVT_WDF_DEVICE_PREPARE_HARDWARE FpcEvtDevicePrepareHardware;
EVT_WDF_DEVICE_RELEASE_HARDWARE FpcEvtDeviceReleaseHardware;

EVT_WDF_IO_QUEUE_IO_WRITE FpcEvtIoWrite;

EVT_WDF_IO_QUEUE_IO_DEVICE_CONTROL FpcEvtIoDeviceControl;

NTSTATUS
FpcSetIdleAndWakeSettings(
    IN PDEVICE_EXTENSION FdoData
    );

NTSTATUS
FpcInitializeDeviceExtension(
    IN PDEVICE_EXTENSION DevExt
    );

NTSTATUS
FpcPrepareHardware(
    IN PDEVICE_EXTENSION DevExt,
    IN WDFCMRESLIST     ResourcesTranslated
    );

NTSTATUS
FpcInitWrite(
    IN PDEVICE_EXTENSION DevExt
    );

NTSTATUS
FpcInitializeHardware(
    IN PDEVICE_EXTENSION DevExt
    );

VOID
FpcShutdown(
    IN PDEVICE_EXTENSION DevExt
    );

VOID
FpcHardwareReset(
    IN PDEVICE_EXTENSION    DevExt
    );

#pragma warning(disable:4127) // avoid conditional expression is constant error with W4

#endif  // _FPC_PRIVATE_H_