#if !defined(_FPC_PUBLIC_H_)
#define _FPC_PUBLIC_H_

//
// The following value is arbitrarily chosen from the space defined 
// by Microsoft as being "for non-Microsoft use"
//
// NOTE: This is still a value for OSR's PLX PCI bridge chips:
//
// GUID_OSR_PLX_INTERFACE GUID
// {29D2A384-2E47-49b5-AEBF-6962C22BD7C2}
DEFINE_GUID (GUID_FPC_INTERFACE, 
   0x29d2a384, 0x2e47, 0x49b5, 0xae, 0xbf, 0x69, 0x62, 0xc2, 0x2b, 0xd7, 0xc2);

// Constants for board identification and resources
#define XILINX_VENDOR_ID 0x10EE
#define FPC_DEVICE_ID    0x7024
#define FPC_DESCRIPTION  "Xilinx FPC Example"
#define FPC_BAR_NUM      0

// Board ID structure
struct fpc_board_id {
  UINT16 vendor;
  UINT16 device;
};

/* Convenience constant for bytes per word (as defined by the driver) */
#define FPC_BYTES_PER_WORD  (sizeof(UINT32))

/* Maximum size for a block of configuration bitstream data */
#define MAX_CONFIG_BLOCK_SIZE (1024)

// Structure definition to carry blocks of configuration bitstream data
struct fpc_data_block {
  UINT32 num_words;
  UINT32 block_words[MAX_CONFIG_BLOCK_SIZE];
};

// Device control codes for use with DeviceIoControl()

// Initializes device reconfiguration
#define IOCTL_FPC_INIT_RECONFIG CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, (FILE_READ_ACCESS | FILE_WRITE_ACCESS))

// Writes a block of configuration data to the device
#define IOCTL_FPC_WRITE_CONFIG CTL_CODE(FILE_DEVICE_UNKNOWN, 0x801, METHOD_BUFFERED, (FILE_READ_ACCESS | FILE_WRITE_ACCESS))

#endif  // _FPC_PUBLIC_H_