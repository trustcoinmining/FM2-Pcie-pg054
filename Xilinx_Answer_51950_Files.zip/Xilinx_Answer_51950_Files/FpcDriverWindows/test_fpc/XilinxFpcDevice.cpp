/**
 * File        - XilinxFpcDevice.cpp
 * Description - See header of ./XilinxFpcDevice.h
 *
 * Copyright (c) 2012, Xilinx
 * All rights reserved.
 */
#include "stdafx.h"

// Class header
#include "XilinxFpcDevice.h"

// STL headers
#include <iomanip>
#include <iostream>
#include <sstream>

// Standard library headers
#include <errno.h>
#include <fcntl.h>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>

// Public driver header
#include "..\FpcDriver\FpcDriverPublic.h"

// Namespace using directives
using std::cerr;
using std::cout;
using std::dec;
using std::endl;
using std::filebuf;
using std::flush;
using std::fstream;
using std::hex;
using std::ifstream;
using std::ios;
using std::istringstream;
using std::list;
using std::make_pair;
using std::map;
using std::setfill;
using std::setw;
using std::string;

// Using directive for Common Language Runtime
//#using <System.dll>
//using namespace System;
//using namespace System::Text::RegularExpressions;

// Implementation of class XilinxFpcDevice

// Virtual Destructor

XilinxFpcDevice::~XilinxFpcDevice(void) {
  if(deviceHandle != INVALID_HANDLE_VALUE) {
    CloseHandle(deviceHandle);
    deviceHandle = INVALID_HANDLE_VALUE;
  }

  // Free the interface details structure
  free(interfaceDetails);
}

// Public interface methods

list<XilinxFpcDevice*> XilinxFpcDevice::getInstances(void) {
  // Dynamically scan for devices by the interface GUID defined publicly
  // by the FPC device driver.
  list<XilinxFpcDevice*> returnDevices;
  uint32_t instanceCount;
  SP_DEVICE_INTERFACE_DATA interfaceData;
  SP_DEVINFO_DATA infoData;
  HDEVINFO infoSet;

  // Retrieve the device information for all FPC devices.
  infoSet = SetupDiGetClassDevs(&GUID_FPC_INTERFACE,
                                 NULL,
                                 NULL,
                                 (DIGCF_DEVICEINTERFACE | DIGCF_PRESENT));

  // Initialize the device interface and info data structures.
  interfaceData.cbSize = sizeof(SP_DEVICE_INTERFACE_DATA);
  infoData.cbSize      = sizeof(SP_DEVINFO_DATA);

  // Iterate through all the devices found in the system by the public driver GUID.
  instanceCount = 0;
  while(SetupDiEnumDeviceInterfaces(infoSet,
                                    NULL,
                                    &GUID_FPC_INTERFACE,
                                    instanceCount,
                                    &interfaceData)) 
  {
    PSP_DEVICE_INTERFACE_DETAIL_DATA interfaceDetails;
    ULONG  resourceSize;
    BOOL   success;
    TCHAR *deviceName;
    TCHAR *hardwareId;

    // Get details about the device's interface.  Begin by dynamically determining the
    // size of the interface details structure to be returned.
    SetupDiGetDeviceInterfaceDetail(infoSet,
                                    &interfaceData,
                                    NULL,
                                    0,
                                    &resourceSize,
                                    NULL);

    if(GetLastError() != ERROR_INSUFFICIENT_BUFFER) {
      // Failed to determine interface details size, try the next device
      cout << "Failed to get device ("
           << instanceCount
           << ") details size, error : "
           << GetLastError()
           << endl;
      instanceCount++;
      continue;
    }

    // Succeeded, allocate enough space for the interface details; the device
    // path is of an indeterminate length.
    interfaceDetails = (PSP_DEVICE_INTERFACE_DETAIL_DATA) malloc(resourceSize);

    if (interfaceDetails == NULL) {
      cout << "Insufficient memory for device ("
           << instanceCount
           << ") interface details" << endl;
      instanceCount++;
      continue;
    }

    // Repeat the call, with an allocated details structure.  Set the cbSize member
    // to the fixed size of the structure.
    interfaceDetails->cbSize = sizeof(SP_DEVICE_INTERFACE_DETAIL_DATA);
    success = SetupDiGetDeviceInterfaceDetail(infoSet,
                                              &interfaceData,
                                              interfaceDetails,
                                              resourceSize,
                                              NULL,
                                              &infoData);

    if(success == FALSE) {
      cout << "Failed to fetch device ("
           << instanceCount
           << ") interface details, error : "
           << GetLastError()
           << endl;
      instanceCount++;
      continue;
    }

    cout << "Got device (" 
         << instanceCount 
         << ") interface details, device path is \""
         << interfaceDetails->DevicePath
         << "\""
         << endl;

    // Get properties about the device
    deviceName = (TCHAR*) getDeviceProperty(infoSet, &infoData, SPDRP_DEVICEDESC);
    hardwareId = (TCHAR*) getDeviceProperty(infoSet, &infoData, SPDRP_HARDWAREID);

    cout << "Got device (" 
         << instanceCount 
         << ") description : \""
         << deviceName
         << "\", hardware ID \""
         << hardwareId
         << "\""
         << endl;

    // Free the character string for the device name
    free(deviceName);
    
    // Parse the hardware ID string, obtaining the vendor and device IDs for use in 
    // creating a tag to search for an appropriate subclass.
    uint32_t vendorId;
    uint32_t deviceId;
    string idString(hardwareId);
    string descString(deviceName);
    size_t vendorPos = idString.find("VEN_");
    size_t devicePos = idString.find("DEV_");

    cout << "idString = \"" 
         << idString 
         << "\", vendorPos = " 
         << vendorPos 
         << ", \""
         << idString.substr((vendorPos + 4), 4)
         << "\", devicePos = " 
         << devicePos 
         << ", \"" 
         << idString.substr((devicePos + 4), 4)
         << "\""
         << endl;

    bool foundIds = false;
    if((vendorPos != string::npos) && (idString.length() >= (vendorPos + 8)) &&
       (devicePos != string::npos) && (idString.length() >= (devicePos + 8))) {
      istringstream vendorStream("0x" + idString.substr((vendorPos + 4), 4));
      vendorStream >> hex >> vendorId;

      istringstream deviceStream("0x" + idString.substr((devicePos + 4), 4));
      deviceStream >> hex >> deviceId;
        
      foundIds = !(vendorStream.fail() | deviceStream.fail());
    }

    // Free the character string for the hardware ID
    free(hardwareId);

    if(foundIds == false) {
      cout << "Failed to locate vendor / device for device ("
           << instanceCount
           << ") in ID string \""
           << idString
           << "\""
           << endl;
      instanceCount++;
      continue;
    }

    // Create a file and get a handle to the device
    cout << "Creating file..." << flush;
    HANDLE deviceHandle = CreateFile(interfaceDetails->DevicePath,
                                     (GENERIC_READ | GENERIC_WRITE),
                                     (FILE_SHARE_READ | FILE_SHARE_WRITE),
                                     NULL,
                                     OPEN_EXISTING,
                                     0,
                                     NULL);
    cout << "done!" << endl;

    if(deviceHandle == INVALID_HANDLE_VALUE) {
      cout << "Failed to create device file for device ("
           << instanceCount
           << ") in ID string \""
           << idString
           << "\", error "
           << GetLastError()
           << endl;
      free(interfaceDetails);
      instanceCount++;
      continue;
    }

    // Locate a creator from the Factory pattern capable of abstracting the device
    // Construct a 32-bit tag from the two identifying values and use it to
    // locate a factory creator for an appropriate instance
    uint32_t boardTag = ((vendorId << 16) | deviceId);
    map<uint32_t, Creator*> &factoryMap(getFactoryMap());
    map<uint32_t, Creator*>::iterator findIter = factoryMap.find(boardTag);
    if(findIter != factoryMap.end()) {
      // Found an appropriate Creator, invoke it to wrap the instance
      returnDevices.push_back(findIter->second->createInstance(deviceHandle, interfaceDetails, descString));
    } else {
      cout << "Unable to locate board abstraction class for vendor 0x"
           << setfill('0') << setw(4) << hex 
           << vendorId
           << ", devce 0x" 
           << deviceId
           << dec 
           << endl;
    }

    // Increment the instance count
    instanceCount++;
  }

  cout << "<<< Found " << instanceCount << " FPC devices" << endl;

  cout << "Press a key..." << flush;
  getchar();

  return(returnDevices);
}

// Protected constructor

XilinxFpcDevice::XilinxFpcDevice(HANDLE deviceHandle,
                                 PSP_DEVICE_INTERFACE_DETAIL_DATA interfaceDetails,
                                 const string &description) :
  interfaceDetails(interfaceDetails),
  description(description),
  deviceHandle(deviceHandle) {
}

// Protected helper methods

void XilinxFpcDevice::configUserPartition(const std::string &binFilename) {
//  struct fpc_data_block dataBlock;
  ifstream bitstreamInput;
  filebuf *bufPtr;
  int32_t ret;
  uint32_t fileSize;
  uint32_t fileWords;
  uint32_t fileBlocks;
  PUCHAR configBuffer;
  ULONG writeWords;
  ULONG bytesWritten;
  DWORD writeError;

  // Allocate a buffer for staging blocks of configuration data into
  configBuffer = new UCHAR[MAX_CONFIG_BLOCK_SIZE * FPC_BYTES_PER_WORD];

  // TEMPORARY DEBUG
  configBuffer[0] = 0xDE;
  configBuffer[1] = 0xAD;
  configBuffer[2] = 0xBE;
  configBuffer[3] = 0xEF;

  // Open the bitstream input file
  bitstreamInput.open(binFilename.c_str());
  if(bitstreamInput.fail()) {
    cout << "Unable to open bitstream file \"" << binFilename << "\" for reading" << endl;
    return;
  }

  // Compute the file size and the consequent number of blocks
  bufPtr = bitstreamInput.rdbuf();
  bufPtr->pubseekpos(0, ios::in);
  fileSize   = bufPtr->pubseekoff(0, ios::end, ios::in);
  fileWords  = ((fileSize / FPC_BYTES_PER_WORD) + ((fileSize % FPC_BYTES_PER_WORD) ? 1 : 0));
  fileBlocks = ((fileWords / MAX_CONFIG_BLOCK_SIZE) + ((fileWords % MAX_CONFIG_BLOCK_SIZE) ? 1 : 0));

  cout << "Configuring user partition with \"" 
       << binFilename 
       << "\": size "
       << fileSize
       << ", "
       << fileWords
       << " words, "
       << fileBlocks
       << " blocks" 
       << endl;

  // Reset the input buffer position to the beginning
  bufPtr->pubseekpos(0, ios::in);

  // Iterate, writing blocks to the driver from the bitstream file
  uint32_t wordsLeft = fileWords;
  while(wordsLeft > 0) {
    // Write maximum-sized blocks until the last one
    writeWords = ((wordsLeft > MAX_CONFIG_BLOCK_SIZE) ? MAX_CONFIG_BLOCK_SIZE : wordsLeft);
    bitstreamInput.read(reinterpret_cast<char*>(configBuffer), (writeWords * FPC_BYTES_PER_WORD));

    // Swap the byte endianness
    for(uint32_t wordIndex = 0; wordIndex < writeWords; wordIndex++) {
      uint32_t swappedWord = 0;
      uint32_t *wordBuffer = reinterpret_cast<uint32_t*>(configBuffer);

      for(uint32_t byteIndex = 0; byteIndex < sizeof(uint32_t); byteIndex++) {
        swappedWord |= (((wordBuffer[wordIndex] >> (byteIndex * 8)) & 0x0FF) << ((sizeof(uint32_t) - byteIndex - 1) * 8));
      }
      wordBuffer[wordIndex] = swappedWord;
    }

    // Write the bitstream chunk to the driver file
    if(!WriteFile(deviceHandle, configBuffer, (writeWords * FPC_BYTES_PER_WORD), &bytesWritten, NULL)) {
      writeError = GetLastError();
      cout << "Write failed: " << writeError << endl;
      return;
    }

    // Decrement the words remaining
    wordsLeft -= writeWords;
  }

  delete[](configBuffer);
}

PBYTE XilinxFpcDevice::getDeviceProperty(HDEVINFO infoSet,
                                         PSP_DEVINFO_DATA infoData,
                                         DWORD property) {
  PBYTE propBuffer = NULL;
  ULONG resourceSize;
  BOOL  success;

  // Retrieve the device property, dynamically allocating a buffer.
  SetupDiGetDeviceRegistryProperty(infoSet,
                                   infoData,
                                   property,
                                   NULL,
                                   (PBYTE) propBuffer,
                                   0,
                                   &resourceSize);

  // The call should fail with an insufficient buffer
  if(GetLastError() == ERROR_INSUFFICIENT_BUFFER) {
    propBuffer = (PBYTE) malloc(resourceSize);
    if(propBuffer != NULL) {
      // Fetch the string into the allocated buffer
      success = SetupDiGetDeviceRegistryProperty(infoSet,
                                                 infoData,
                                                 property,
                                                 NULL,
                                                 (PBYTE) propBuffer,
                                                 resourceSize,
                                                 NULL);
      if(success == FALSE) {
        // Free the allocated buffer and set it to NULL
        free(propBuffer);
        propBuffer = NULL;
      }
    }

  }

  // Return the dynamically-allocated buffer, or NULL
  return(propBuffer);
}

// Private helper methods

const bool XilinxFpcDevice::createNode(const string &devName, const string &nodeName) {
  int32_t major = 0;
  int32_t minor = 0;
  bool success;

#ifdef NOTYET

  // Locate the device by its miscellaneous device class, returning failure
  // if the misc device does not exist.
  string devPath = "/sys/class/misc/" + devName + "/dev";
  char buf[16];
  int32_t fd = ::open(devPath.c_str(), O_RDONLY);
  if(fd < 0) return(false);

  // Create the device node pathname
  ssize_t read_bytes;

  memset(buf, 0, sizeof(buf));
  if((read_bytes = read(fd, buf, sizeof(buf))) == 0) {
    cerr << "Unable to read from sysfs entry for \""
         << devName
         << "\""
         << endl;
  }
  close(fd);
  buf[sizeof(buf)-1] = 0;
  sscanf(buf, "%d:%d", &major, &minor);
    
  // First attempt to unlink any stale node from a previous run.
  int32_t returnCode = ::unlink(nodeName.c_str());
  success = ((returnCode >= 0) | (errno == ENOENT));

  // Create the device node
  if(success) {
    returnCode = ::mknod(nodeName.c_str(), S_IFCHR | 0777, (major<<8) | minor);
    if(returnCode < 0) {
      cerr << "Error creating device node \""
           << nodeName
           << "\" at major / minor ("
           << major
           << ", "
           << minor
           << ") : "
           << strerror(errno)
           << endl;
      success = false;
    }
  }

#else
  success = true;
#endif

  return(success);
}

XilinxFpcDevice*
XilinxFpcDevice::abstractDevice(const std::string &nodeName) {
  XilinxFpcDevice *retInstance = NULL;
  int32_t nodeHandle;
  int32_t retValue;

#ifdef NOTYET

  // Open the device node for use
  if((nodeHandle = ::open(nodeName.c_str(), O_RDWR)) > 0) {
    // Opened successfully, perform an I/O control operation to obtain the
    // vendor and product ID for the board
    struct fpc_board_id board_id;

    if(ioctl(nodeHandle, IOC_GET_BOARD_ID, &board_id) != 0) {
      retValue = errno;
      cerr << "Failed to complete I/O control to \""
           << nodeName
           << "\", error "
           << retValue
           << endl;
    }

    // Construct a 32-bit tag from the two identifying values and use it to
    // locate a factory creator for an appropriate instance
    uint32_t boardTag = ((board_id.vendor << 16) | board_id.device);
    map<uint32_t, Creator*> &factoryMap(getFactoryMap());
    map<uint32_t, Creator*>::iterator findIter = factoryMap.find(boardTag);
    if(findIter != factoryMap.end()) {
      retInstance = findIter->second->createInstance(nodeName, nodeHandle);
    } else {
      cout << "Unable to locate board abstraction class for vendor 0x"
           << setfill('0') << setw(4) << hex 
           << board_id.vendor
           << ", product 0x" << board_id.device
           << dec << endl;
    }
  }

#endif

  // Return the instance, or NULL if a failure occured
  return(retInstance);
}

map<uint32_t, XilinxFpcDevice::Creator*>& XilinxFpcDevice::getFactoryMap(void) {
  static map<uint32_t, Creator*> factoryMap;

  // Return the static instance, which is implicitly created upon the
  // first invocation of the method
  return(factoryMap);
}

// Protected type implementations

// Class XilinxFpcDevice::Creator

// Public interface

XilinxFpcDevice::Creator::Creator(uint16_t boardVendor, uint16_t boardDevice) {
  // Register the instance as the creator for the passed board info
  uint32_t boardTag = ((boardVendor << 16) | boardDevice);
  XilinxFpcDevice::getFactoryMap().insert(make_pair(boardTag, this));
}

XilinxFpcDevice::Creator::~Creator(void) {
}
